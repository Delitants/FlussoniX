# Direct SRTP and SRTCP

The direct MPEG-TS RTP profile also supports `srtp://IP:PORT` in both directions. RTP is encrypted and authenticated with AES_CM_128_HMAC_SHA1_80; the consecutive RTCP port uses encrypted authenticated SRTCP with an independent packet index and replay state. The native transport loads the independent system `libsrtp2.so.1` (libSRTP 2.x). Install the distribution's `libsrtp2-1` runtime package; Flussonic packages, Erlang modules and proprietary drivers are unnecessary. If the library, profile or key cannot be initialized, secure transport fails closed. It never sends or accepts plaintext as a fallback.

Use the normal input or destination URL field, with `srtp://` instead of `rtp://`. The SRTP key file field holds an absolute path on that node, not a key pasted into the browser. Its API field is `flussonix_rtp.key_file`. Each file contains one base64 encoding of exactly 30 bytes: 16-byte master key followed by 14-byte master salt. Leading/trailing ASCII whitespace is accepted. The opened file must be regular, owned by the daemon UID, inaccessible to group/other users and at most 128 bytes. Final-component symlinks are rejected; non-regular files are opened nonblocking then rejected. The application erases key-loading buffers after session creation. Runtime counters and errors disclose neither key bytes nor file paths; authenticated administrators can edit the saved reference.

Create a separate secret file through your server's normal secret provisioning, for example:

```sh
install -d -m 700 /etc/flussonix/keys
(umask 077; openssl rand -base64 30 > /etc/flussonix/keys/channel.key)
```

Set its ownership to the daemon's service UID. Provision the same key/salt to the peer over an authenticated management channel. Do not put key material in media URLs, source-controlled configurations or command logs. There is no DTLS-SRTP or automatic key negotiation. Independent senders using a master key must avoid SSRC/index reuse.

Before admitting direct SRTP input, initialize an owner-only receiver history once and pass its path to the daemon:

```sh
sudo install -d -o flussonix -g flussonix -m 700 /var/lib/flussonix
sudo -u flussonix flussonix --init-srtp-receiver-ledger /var/lib/flussonix/srtp-receiver-epochs
sudo -u flussonix flussonix --srtp-receiver-ledger /var/lib/flussonix/srtp-receiver-epochs \
  --listen 127.0.0.1:18210 --config /etc/flussonix/config.json
```

Run both commands as the service UID. Initialization refuses an existing history; keep the history across daemon restarts and backups. A successful receiver generation claims its key before admitting packets. Restarting with the same key is denied, so provision a fresh sender key and coordinate a new sender generation. If the history is missing or unsafe, the receiver fails closed and releases its UDP ports. The opt-in input setting `flussonix_rtp.allow_legacy_reused_key: true` permits an old static key to be used again, with weaker replay protection; it does not remove track-identity checks. Streams and Templates expose this as a separate checkbox.

Open the required UDP path and start the sender before starting a receiver with a new key. A receiver startup that claims its key but fails before media arrives still consumes that key epoch. Restoring the path afterward requires another coordinated sender and receiver key rotation; the receiver will not reuse the claimed key on retry.

The authenticated capabilities API and the admin UI show whether receiver history is configured and healthy. Its parent directory must be owned by the service UID and allow owner read/write/search. A new or expired check can briefly show “Checking”; the result is cached for 30 seconds. The status never includes the history path or key fingerprints. An unhealthy status does not turn on the legacy override.

For elementary SRTP input, choose one protection mode in the form. A shared `key_file` may protect one track; for multiple tracks, enter `expected_ssrcs` in SDP media order. Any `a=ssrc` declared by the sender's SDP must match the corresponding configured value; if SDP omits it, the configured value still binds that track's packets. Alternatively, enter one `track_key_files` path per SDP media track; all files must contain different key material. The receiver validates 1–8 tracks, loads one immutable snapshot of each key, opens all required RTP/RTCP pairs, and claims the whole key set atomically before media admission. A captured packet from one track cannot establish another track's peer or enter its startup queue. For elementary SRTP output, use either one shared `key_file` or `track_keys` rows keyed by the active track ID, media and encoding. Per-track output keys must also contain different bytes; a changed track set stops that destination and withdraws its SDP until the mapping is updated. Active track IDs and codecs appear in the Streams editor when the worker has them.

The receiver authenticates before pinning its media peer and before releasing TS to the decoder. It uses a 128-packet replay window and rejects wrong keys, modified packets, duplicates, plaintext, source changes and oversized frames. The libSRTP adapter pins one authenticated SSRC to bound stream-context state. Media address pinning additionally requires a valid MP2T payload. RTCP is accepted only from the media peer's consecutive port, after authentication; outgoing feedback is protected and directed only to that peer. Destination feedback is authenticated on the connected RTCP socket and pins one feedback SSRC.

Keys are loaded once per worker generation. Editing the key-file reference or explicitly restarting a stream reloads the file and replaces both transport sessions, sockets, random SSRCs, sequence seeds and clocks. Replacing bytes at an unchanged path alone does not force an automatic restart. Rotate all elementary input track keys together, and update the sender and receiver as one coordinated generation. A failed destination does not automatically reuse its sender session. Its error stays visible until a new generation starts.

A temporary UDP refusal follows the MP2T destination recovery behavior in the [RTP profile](direct-rtp.md). Sender identity and crypto contexts remain intact. Each protected RTP sequence/index is consumed even when its packet is refused; protection indices are never reused and skipped ciphertext is not retransmitted. A returning receiver that retains its SRTP context can continue across the gap. A newly initialized receiver does not automatically know an existing nonzero rollover counter; this change adds no rollover negotiation or automatic rekeying.

The [RTP profile](direct-rtp.md) describes multicast, codecs, pacing, worker sharing, subtitle policies and uplink accounting. Encryption does not change TS codec/subtitle capabilities. Inbound authorization is the configured endpoint, optional source-IP filter and possession of the SRTP key; this UDP profile does not invent an HTTP viewer-token handshake. Outbound destinations are configured pushes, not separately authenticated viewers.

Interoperability tests use independent FFmpeg SRTP peers as well as library-level packet tests. CPU encoding and available Intel H.264 VAAPI source fixtures are short, low-resolution delivered-media checks. This host's HEVC VAAPI encoder is unavailable with its test driver; HEVC transport is qualified using CPU-generated sources. Internal VAAPI transcoder controls and hardware throughput qualification remain separate pending work.

Receivers must start with a fresh sender epoch (initial rollover counter zero). A new receiver joining an already running SRTP sender after its first 16-bit sequence rollover lacks the sender's rollover state and fails authentication; a replay-window reset alone cannot recover it. Coordinate a fresh sender generation and key when restarting or moving a receiver. Configurable initial ROC, negotiated context transfer and unsignalled late joining remain pending, including for multicast. Existing authenticated receiver sessions handle sequence rollover normally. Packet tests prove both continued-session rollover and fresh-receiver rejection; media tests start coordinated fresh epochs.
