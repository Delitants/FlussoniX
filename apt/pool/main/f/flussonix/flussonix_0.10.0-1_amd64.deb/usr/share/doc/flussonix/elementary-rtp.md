# Elementary RTP with static SDP

Select **Elementary RTP (SDP)** in Streams or Templates for direct RTP or SRTP input and destinations. MPEG-TS/PT33 remains the default. Encrypted elementary uses key-free RTP/SAVP and owner-only key references; see [secure setup and session limits](elementary-srtp.md). SDP negotiation, SAP and WebRTC remain pending.

Input requires a literal, concrete IP URL `rtp://IP:PORT` or `srtp://IP:PORT` and an absolute **RTP input SDP file** reference. The file must be regular, owned by the daemon user, not writable by group/others, at most 16 KiB and not a symlink. No SDP JSON editing, inline credentials or remote descriptor fetching is needed. The descriptor's first connection and port must match the URL; all tracks use that IP, with distinct RTP ports and their consecutive RTCP ports. Port range is 1024–65520 at the URL. Reserve room through the base port plus 15 for up to eight tracks.

The static RTP/AVP or encrypted RTP/SAVP profile accepts one H.264 or single-layer HEVC video track and multiple AAC-LC, MPEG Layer II or MP3 audio tracks, including audio-only streams. There are at most eight tracks. H.264 uses packetization mode 1; HEVC uses single NAL, AP and FU without decoding-order negotiation. AAC uses indexed AAC-LC configuration, fixed 13/3/3 AU headers and noninterleaved complete AUs. MPEG audio uses the RFC 2250 four-byte header and 90 kHz clock. Dynamic types are 96–127; MPEG audio may use static PT14. Separate ports and SSRCs distinguish audio tracks with equal payload types. Unsupported codecs, attributes, cryptography and resource indirection are rejected.

Independent FFmpeg's AAC SDP emitter omits `streamtype`. The parser accepts that omission only after validating AAC-LC configuration and the fixed framing, then supplies audio streamtype 5 to the private decoder. See [FFmpeg's SDP emitter](https://github.com/FFmpeg/FFmpeg/blob/n7.1.1/libavformat/sdp.c) and [RFC 3640](https://www.rfc-editor.org/rfc/rfc3640).

Native sockets validate bounded codec payloads before pinning a media address and SSRC. An optional exact source IP filter and the existing 64-packet jitter/reorder window apply per track. Plaintext RTP source pinning is not cryptographic authentication. IPv4 multicast needs an explicit interface; group-specific binds isolate groups sharing ports. IPv6 unicast is supported, IPv6 multicast is pending.

For direct RTP or SRTP inputs, **RTP receive buffer (MiB)** optionally requests 0.0625–32 MiB for each public RTP socket, including MPEG-TS/PT33 input. Leave it blank to keep the host default. This is `flussonix_rtp.receive_buffer_bytes` in the saved input, measured in bytes; it does not apply to RTCP or outputs. On Linux, raise `net.core.rmem_max` if the requested capacity is capped. Startup fails visibly when the kernel cannot grant the requested size, and the input ports are released. A larger socket buffer may help absorb receive bursts, but it is not a repair for the archived HEVC picture-loss cases described below.

The worker receives a regenerated SDP containing only validated codec parameters and owned loopback decoder ports. FFmpeg never receives the original addresses, file reference, arbitrary protocol attributes or public sockets. Before admitting public RTP or RTCP, managed worker startup verifies that every exact loopback RTP/RTCP port belongs to that worker's decoder PID, excluding the released handoff reservation inodes. Port occupancy by another process cannot make it ready. Decoder startup, relay writes and teardown are bounded. Input diagnostics retain the specific static startup/relay failure without exposing SDP paths or key material. This uses the same trusted daemon-host loopback boundary as other private worker bridges. RTCP sender reports reach the private decoder only after matching a pinned media peer and SSRC; valid receiver feedback returns only to that peer's consecutive port.

Each of up to four destinations uses the shared worker's native packetizer, with one RTP/RTCP pair per actual track at base + 2 × track index. There is no per-destination encoder. Random session timestamp origins preserve relative spacing. Native reconstruction keeps full AAC/MPEG sample duration through source-clock overlaps of at most 250 ms and preserves forward gaps; larger overlap fails the generation. See [the audio clock contract](worker-output-ts.md). Related tracks share one RTCP CNAME and a stable media/wall clock mapping, retaining presentation offsets despite send delays. Enabled destinations on the same IP must have non-overlapping reserved ranges (16 ports for elementary, two for MP2T); disabled rows and distinct groups can reuse ports. Rate pacing, datagram bounds, queue-lag detection, cancellation and codec-generation fences apply. Direct RTP/RTCP bytes and IP/UDP overhead contribute to existing uplink telemetry. Kernel sends are not delivery acknowledgements. A receiver-port ICMP refusal is counted as `unreachable_packets`; it does not stop the source or prevent downloading SDP for a late receiver. Other socket errors and queue lag fail the destination visibly.

After active media starts, use **Output → View SDP / Download SDP**. Authenticated GET `/flussonix/api/v1/rtp-sdp/STREAM?destination=0` returns `application/sdp` with `Cache-Control: no-store`. Indices are 0–3. This read does not start a source. Disabled, inactive, changed-target or superseded codec descriptions return conflict instead of stale SDP. A receiver must reload SDP after a worker or codec change. The UI discards descriptions when the worker/generation changes.

For an independent FFmpeg receiver, allow the file/UDP/RTP protocols and open the downloaded SDP. Copy-only remuxing of RTP audio requires `-copyinkf:a`, since depacketizers can omit audio key flags:

```sh
ffmpeg -protocol_whitelist file,udp,rtp -f sdp -i receiver.sdp \
  -map 0 -c copy -copyinkf:a -f mpegts received.ts
```

CPU-transcoded outputs use the same worker path. Internal VAAPI H.264 is opt-in qualified on the available iGPU; hardware HEVC is not qualified on this host. Separate DVB/teletext subtitle tracks need MPEG-TS carriage rather than this AV elementary profile. Embedded CEA carriage follows the existing copy/processing path but this first elementary matrix does not qualify its subtitle combinations.

Qualification uses independent FFmpeg senders and SDP receivers, exact codec/frame checks and strict decode: H.264 and HEVC paired with AAC/MP2/MP3, AAC audio-only, distinct MP2+MP3 tracks, and actual CPU video/audio conversion. Native tests cover malformed/foreign admission, reorder, RTCP, authenticated SDP, zero media epoch, late receivers, stale target/generation, shared workers and reaping. These small localhost fixtures do not establish WAN, sustained throughput or a complete Flussonic direction matrix.

### Decoder startup buffering

Elementary RTP/SRTP input now reads and validates public packets while its
private decoder starts. Each track holds at most 1,024 admitted RTP packets or
2 MiB, plus at most 64 authenticated RTCP packets or 128 KiB. The oldest queued
packet is discarded if either limit is reached; `startup_dropped_packets` and
`startup_dropped_rtcp_packets` expose these discards separately from RTP
sequence loss. Public packets still cannot reach any private socket until all
RTP/RTCP ports belong to the expected decoder process. Failed startup,
cancellation and input replacement discard the queue.

An owned two-track SRTP regression sends packets before decoder binding,
rejects wrong-key, malformed and foreign candidates, proves no early private
delivery, and checks buffered RTP/SRTCP after binding. Separate tests exercise
the RTP and RTCP limits, track isolation, arrivals during drain and cancellation
with queued media. A fresh 27-case plaintext/secure localhost media run on the
candidate strictly decoded the worker and independent receiver recordings.
All 27 evidence files finished qualified and complete, with zero native
startup discards, native RTP sequence loss and observed UDP socket drops.
These observations do not prove the older intermittent HEVC picture loss is
fixed: that specific failure did not recur, and the packet taps in that run
began after private decoder readiness. The queue cannot recover network loss,
packets discarded before its reader starts, or a burst beyond its fixed cap.

### Elementary HEVC release disposition

Exact head `f235001d78186f8f92710d15a7d02ad3060cd29a` passed 26 consecutive
HEVC/MP3 plaintext runs with packet taps and strict worker and independent
receiver decoding: one initial run followed by a 25-run repeat completed in
121.894 seconds. Every repeat retained at least 277 native input packets, 298
public packet records and 215 private packet records; the initial run retained
281 public and 216 private packet records. Across the gate, observed kernel
drops, native sequence loss, startup RTP/RTCP drops, invalid packets,
authentication failures and foreign packets were zero, and the retained tap
evidence was complete.

This bounded localhost result closes the archived observation as a release
blocker for the supported direct elementary RTP/SRTP profile. The archived
38-picture loss remains historical diagnostic context: its cause is unknown,
and non-reproduction does not assign a root cause or prove that a particular
change repaired it. The gate does not establish WAN reliability, sustained
capacity, recovery after actual packet loss or an unbounded guarantee for
every host and workload.

Direct RTP/SRTP over UDP cannot recover packets lost in the network, discarded
by the kernel, delayed by runtime starvation or delivered in a burst beyond
the per-track startup queue. The fixed limits remain 1,024 admitted RTP
packets or 2 MiB and 64 authenticated RTCP packets or 128 KiB per track;
`startup_dropped_packets`, `startup_dropped_rtcp_packets`, native sequence-loss
statistics and socket-drop observations remain the operator signals. Use SRT
or FXLink for lossy or long-haul links that need transport recovery.

## Investigating intermittent media loss

The independent elementary fixtures can retain private evidence with
`FLUSSONIX_ELEMENTARY_ARTIFACT_DIR=/absolute/owned/directory cargo test --locked --test elementary_media --test elementary_srtp_media -- --test-threads=1`.
Use a new empty directory for each run. Each codec case reserves a new private directory before evidence collection or media startup. Existing case paths, including empty directories and symlinks, are rejected with an instruction to choose another artifact directory. Previous evidence and caller files are left untouched.
This option changes only the test harness; it does not enable server-side packet logging or change socket buffers.

Each case records `boundary-evidence.jsonl` before sender startup and throughout delivery, including fixture stages, native worker statistics, process identity, host I/O pressure, observation/write durations, and the watched processes' owned IPv4 UDP sockets. Socket records include local/remote ports, inode, queue sizes and cumulative kernel receive drops. The sender, native test process, worker and independent receiver have separate roles. Ownership is checked using descriptor inodes and process start time; a missing observation is explicitly unavailable, rather than a zero drop measurement. A background thread owns collection and writes. Fixture notifications use a bounded nonblocking queue; queue delays and dropped notifications are explicit, and the final fixture stage is retained separately from queued events. Sampling occurs approximately every 100 ms for at most 60 seconds, with an 8 MiB evidence limit that reserves space for a minimal final stage/failure record. Descriptor races are marked partial. Other simultaneously running tests can own sockets in the same native test process, so use the serial invocation above and correlate ports rather than assuming every row belongs to an input lane.

A positive drop count identifies a socket that discarded incoming datagrams. A successful send, zero observed drops, or a passing rerun does not prove end-to-end delivery: a short-lived socket may close between samples, losses can occur elsewhere, and observation itself can affect scheduling. Additional packet capture may still be needed to locate missing HEVC pictures. An experimental synchronous collector reproduced HEVC/MP2 missing pictures with 56 kernel drops on the public video input, matching 56 native sequence losses. A later HEVC/MP3 repeat recorded 295 public input drops and a 6.66-second evidence write. That collector could itself block fixture stage notifications during disk stalls, so these reproductions cannot establish the cause of production loss. A real blocked-FIFO regression detects that observer defect, and the final collector uses nonblocking notifications. Offline comparison of the archived older HEVC/MP3 failure confirmed the same 38-picture gap in the worker recording and native RTP output. Its matching snapshot reports 91 aggregate input reorder gaps; an earlier zero-loss note conflicts with that archive. These are missing sequence positions across input lanes, not a video-specific kernel-drop measurement. The loss cause and the older HEVC/MP2 startup failure remain unresolved. These diagnostics are not a media-loss repair.

The synthetic fixture's worker recording now uses asynchronous file writes, so a slow recording write cannot block its single-thread Tokio RTP receiver. An owned FIFO regression stalls the write, checks that the runtime remains responsive and that the complete chunk is recorded; deliberately restoring the blocking write makes that regression fail. This removes one test-harness scheduling confounder. It does not identify the cause of the archived HEVC loss or change production media code.

On success or assertion unwinding, the guard attempts to retain the available sender/receiver logs, sanitized SDP and worker/receiver recordings. Inline SDP crypto attributes and key files are excluded; these fixtures use synthetic media and a fixed test key. Case directories are owner-only and retained files are owner-readable/writable. Log/SDP retention is limited to 1 MiB per file and each recording to 64 MiB. CI enables this evidence collection for Rust qualification, but the workflow does not upload its private directory; the runner removes it after the job. Output datagram evidence is buffered up to 4 MiB per lane during delivery and saved by the observer after the worker stops; overflow fails the fixture. Worker logs pass through the same capped retention helper. Shutdown waits at most two seconds for the observer. A timeout reports a best-effort snapshot of the current observer operation, milliseconds since it was marked, the latest fixture stage and timeout status using in-memory metadata; operation labels are fixed and include no private paths or stream configuration. The metadata lock is never held during observation or filesystem I/O. The observer may advance after the deadline and before this snapshot, so the reported operation helps investigate a stall but does not prove which operation caused the timeout or attribute a media failure to it. A timeout fails a normal fixture explicitly; during assertion unwinding it reports incomplete evidence without replacing the original failure. A blocked observer may remain detached until its filesystem operation completes or the test process exits; it owns no media child and retains only a weak worker reference. Missing terminal records and `incomplete` markers must be treated as incomplete observations. Oversized retained files are skipped and reported. The artifacts must never be populated from operator streams or production keys.


### Optional passive packet taps (Linux)

For a local owned-fixture investigation, add `FLUSSONIX_ELEMENTARY_PACKET_TAPS=1` to the serial qualification command above. This requires Linux `CAP_NET_RAW`, the system `/usr/bin/ffmpeg`, and a fresh artifact directory. Normal tests and CI do not enable this option or require capture privileges. An explicitly requested tap that cannot be created fails setup and records unavailable evidence; it does not silently continue with an empty trace.

Two independent AF_PACKET sockets observe `source_to_public` and `relay_to_decoder`. The public tap starts before the owned sender is spawned, while the fixture still holds the input-port reservations. It keeps one packet socket across sender startup, reservation release and native input binding. Its locked kernel filter admits only exact loopback public destination ports; the sender's source ports are unknown before spawn. After SDP startup the tap snapshots the sender's PID, start time and exact UDP source-port/inode set; FFmpeg's unconnected wildcard sockets are accepted. Before retaining raw evidence, it checks that captured source ports match the unchanged sender's later socket witness and that userspace observation timestamps follow the sender-spawn marker. A foreign source port, changed socket owner, incomplete capture or failed handoff discards the whole raw public trace. **Packets before the sender socket witness remain candidates, not proven FFmpeg output:** a later matching port does not establish process ownership at the earlier send time, and userspace observation time can lag kernel delivery. The private decoder tap still begins after decoder readiness and uses its original destination-only filter and ownership checks. Both filters reject unrelated destinations, non-loopback traffic, IP options and fragments; only loopback host copies are retained.

The capture threads buffer at most 4 MiB per boundary for at most 60 seconds and perform no filesystem writes. The fixture briefly pauses only its synthetic sender before stopping the taps, leaving its sockets available for the final ownership witness and allowing queued capture packets to drain. It kills and reaps the sender after tap stop, then submits buffers to the asynchronous observer after worker shutdown. If ownership is unavailable or changed, the entire ambiguous trace is discarded and evidence is explicitly unavailable/incomplete. Each `*.packets` file consists of BE32 frame lengths, followed by BE64 nanoseconds since the shared fixture origin, BE16 source and destination ports, and the unchanged UDP payload. These are userspace observation times, not kernel receive or media presentation timestamps. The tap is active from before spawn, but the verified sender prefix remains unobserved; early records are source-port candidates. Handoff packets remain sender-to-public attempts, not acknowledgments from the native reader. RTP headers provide sequence, SSRC and media timestamp correlation; encrypted public SRTP payloads remain encrypted while the private decoder boundary carries plaintext. Test keys are never included in these files.

`packet_taps` summaries in `boundary-evidence.jsonl` report coverage and handoff timestamps, reservation/sender/native witnesses, destination ports, retained records, ignored outgoing copies, packet-socket kernel drops, queued data at stop, truncation, caps and receive/completion errors. They label the early sender prefix `candidate_only`. Unknown counters stay unavailable. Drops, queued data, caps, time limits and failures mark evidence incomplete. The public handoff tap discards incomplete raw bytes; the private decoder tap may retain raw bytes marked incomplete for diagnosis. Both unverified prefix attribution and the private post-readiness start remain explicit limits. These are passive kernel-path observations, not acknowledgements of native input admission or FFmpeg consumption. Capture can itself affect scheduling, and a passing captured run does not resolve the earlier intermittent HEVC failures. Use only the synthetic fixture, never operator streams or production keys. Packet socket setup/filtering follows the [Linux socket filter documentation](https://www.kernel.org/doc/html/latest/networking/filter.html).
